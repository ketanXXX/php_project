<?php
    $conn = mysqli_connect("localhost","root","","register") or die(mysqli_connect_error());
?>