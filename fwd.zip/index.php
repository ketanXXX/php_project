<?php

    include('db.php');
?>

<!DOCTYPE html>
<html>
  <head>
	<title>Welcome Home</title>
    <link rel="stylesheet" href="sty.css">
  </head>
  <body>
    <div class="gin">
        <h1>Welcome User</h1>
        <a href="log.php">Logout</a>
    </div>
  </body>
</html>