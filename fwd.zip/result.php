<!DOCTYPE html>
<html>
  <head>
	<title>Welcome Home</title>
    <link rel="stylesheet" href="sty.css">
  </head>
  <body>
    <div class="gin">
        <h1>Signup Sucessfully!!</h1>
    </div>
  </body>
</html>